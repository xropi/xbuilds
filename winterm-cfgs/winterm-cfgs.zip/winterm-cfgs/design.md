# design.md

A folder of per-machine Windows Terminal configs, plus `apply-keybindings.py`,
which copies the `keybindings` section from one of them into the live
`settings.json`. There is no `-orig`. `<project>-D<n>` cites another project's
decision record, e.g. `ccx-D19`.

## Decided

**D1: the section is spliced as text, not parsed and re-dumped.** The script locates
the byte range of the `keybindings` value in both files with a small JSONC scanner
(strings, escapes, `//` and `/* */`) and swaps one range for the other. Rationale:
both files are JSONC. The configs here use `//` comments to group bindings by
purpose (`// pane split`), and the live file may have commented-out entries.
`json.load`/`json.dump` drops every comment and reformats the entire file, turning a
one-section change into a whole-file rewrite. Text splicing leaves everything outside
the section byte-identical. Cost: a hand-written scanner instead of the stdlib parser
— about 60 lines, and the input grammar is small and fixed.

**D2: both files are still parsed, for validation only.** Before and after the
splice, a comment-stripped copy goes through `json.loads`. Rationale: the scanner
finds delimiters but does not verify the content between them, and the one thing
worse than not applying the config is leaving Windows Terminal with a settings file
it refuses to load. The stripper replaces comments with spaces rather than deleting
them, so reported line numbers still match the real file, and it also drops trailing
commas, which Windows Terminal tolerates and `json.loads` does not.

**D3: the block is re-indented, then the whole file is normalized to the target's
line endings.** Indentation is shifted by the difference between the source key's
indent and the target key's. Rationale: a block moved between two files that both
use 4 spaces needs nothing, but this survives a hand-edited config; and splicing an
LF block into a CRLF file otherwise leaves mixed endings in one file.

**D4: the Windows user is found through `cmd.exe`, not by guessing paths.** On
Windows, `%LOCALAPPDATA%` straight from the environment. On WSL,
`cmd.exe /c echo %LOCALAPPDATA%` (with `cwd=/mnt/c`, so cmd.exe does not warn about a
UNC working directory) put through `wslpath -u`; if `wslpath` is missing, a manual
`C:\…` → `/mnt/c/…` rewrite; and only as a last resort, a scan of `/mnt/c/Users` for
the single profile that has a Windows Terminal config. Rationale: the answer is
authoritative instead of heuristic, and it costs one subprocess. No PowerShell — a
global rule, and `cmd.exe` does the job. The scan is kept as a fallback because it is
the one path that still works when interop (`/proc/sys/fs/binfmt_misc/WSLInterop`) is
disabled, but only when it is unambiguous.

**D5: four install locations are probed in a fixed order** — packaged stable,
Preview, Canary, then unpackaged `%LOCALAPPDATA%\Microsoft\Windows Terminal`. The
first hit wins and its full path is printed; if more than one exists the script says
so and names `--target`. Rationale: on a normal machine exactly one exists, so
prompting would be ceremony; printing the path it chose makes a wrong guess visible
immediately, and `--target` is the escape hatch.

**D6: a same-day backup is never overwritten.** The backup is
`settings-YYYY-MM-DD.json` next to the target, and on collision `-2`, `-3`, … are
appended. Rationale: the point of the backup is the state *before this run*; applying
two configs in one day would otherwise leave a "backup" that is itself one of the
generated states, and the original would be gone.

**D7: no installer, no dependencies, no launcher.** Stdlib only, plain
`#!/usr/bin/env python3`, run by path. Rationale: dev-D11's rule that a project with
no runtime dependencies bootstraps nothing. The folder ships as a plain zip (dev-D10),
and the script must also run on the Windows side, where the uv-shebang launch does
not apply.

**D8: the b45 profiles use a patched copy of Solarized Dark, not the built-in
scheme.** `"Solarized Dark (wxl)"` in `schemes` is the measured built-in palette
with one value changed: `brightBlack` `#073642` → `#586E75` (Solarized base01).
Rationale: stock Solarized spends its bright slots on the grey ramp, so bright
black lands one step off the background — `#073642` against `#002B36` is about
1.16:1, legible only as a smudge. Every tool that treats bright black as "dim"
therefore writes near-invisible text. The case that prompted it: Claude Code
highlights fenced code with highlight.js and colours the tokens with
cli-highlight's default map, where hljs `meta` is `chalk.grey`, i.e. ANSI 90. In
C/C++ the directive word of `#define` is a keyword and `<…>` after `#include` is a
string — both mapped to plain foreground — but the `#` and a macro name are bare
`meta`, so `#define FOO 1` showed as a readable `define` between unreadable parts.
That colour is inside the `claude` binary and is not part of its theme object, so
`/theme` cannot reach it; the terminal palette is the only end under our control.
Windows Terminal has no per-colour override for a built-in scheme, so a full copy
is the only form the change can take. `#586E75` now collides with `brightGreen`,
which Solarized also maps there; accepted, because staying inside the Solarized
ramp is what keeps the rest of the look identical.

## Open

**O1: only `keybindings` is handled.** `actions` (the command definitions the
`Terminal.*` ids in `keybindings` refer to) and `schemes` are the obvious next
candidates, and the splice machinery is already section-agnostic — `SECTION` is a
constant. Undecided whether to generalize it to a `--section` flag or to keep the
script doing one thing. D8 makes `schemes` concrete rather than hypothetical: that
edit was applied to both files by hand, which is the second section this folder
now tracks and the script still cannot move.
