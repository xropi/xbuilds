# CLAUDE.md

## What this is

Windows Terminal settings, one file per machine (`<machine>-win-terminal-settings.json`),
plus `apply-keybindings.py`, which copies the `keybindings` section out of one of
them into the machine's live `settings.json`.

Not a code project: no installer, no dependencies, no build. `make-bins.py` at the
repo root ships the whole folder as a plain zip (dev-D10). The decision record is
`design.md`.

## Non-obvious constraints

- **Both sides are JSONC, not JSON.** Windows Terminal accepts `//` comments, and
  the config files here use them to group the bindings. `json.load` + `json.dump`
  would silently delete every comment and reformat the whole file, so the script
  splices the section as *text* (D1) with a small scanner that knows about strings
  and comments.
- The live `settings.json` is written by Windows Terminal itself: UTF-8 **with BOM**
  and CRLF. Both are preserved on write.
- Run it from WSL or from Windows. On WSL the Windows user comes from
  `cmd.exe /c echo %LOCALAPPDATA%`, run with `cwd=/mnt/c` so cmd.exe does not print
  its UNC-working-directory warning.

## How to run

```sh
./apply-keybindings.py --list          # configs here + settings.json found
./apply-keybindings.py b45 --dry-run   # unified diff, writes nothing
./apply-keybindings.py b45             # backs up, then writes
```

The source argument is resolved as a path first, then as a bare name against this
folder (`b45` → `b45-win-terminal-settings.json`). `--target PATH` overrides the
detected file — that is also how to test against a copy instead of the real one.

There are no tests; check changes with `--dry-run` and with a throwaway `--target`.
