#!/usr/bin/env python3
"""Replace the "keybindings" section of the Windows Terminal settings.json
with the one from a given config file.

Works on Windows and on WSL (the Windows user is detected through cmd.exe).
The target file is always backed up as settings-YYYY-MM-DD.json next to it
before it is touched.

The replacement is done on the *text*, not by parsing and re-dumping JSON, so
comments and formatting survive on both sides -- both files are JSONC, which
is what Windows Terminal actually accepts.
"""

import argparse
import datetime
import difflib
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

SECTION = "keybindings"

# Relative to %LOCALAPPDATA%, in the order we prefer them.
TARGET_CANDIDATES = [
    "Packages/Microsoft.WindowsTerminal_8wekyb3d8bbwe/LocalState/settings.json",
    "Packages/Microsoft.WindowsTerminalPreview_8wekyb3d8bbwe/LocalState/settings.json",
    "Packages/Microsoft.WindowsTerminalCanary_8wekyb3d8bbwe/LocalState/settings.json",
    "Microsoft/Windows Terminal/settings.json",  # unpackaged / portable install
]

SCRIPT_DIR = Path(__file__).resolve().parent


# --------------------------------------------------------------------------
# JSONC scanning
#
# Just enough of a scanner to find where a top-level key's value starts and
# ends. It knows about strings, escapes, // and /* */ comments -- that is all
# a settings.json can contain.
# --------------------------------------------------------------------------

class JsoncError(Exception):
    pass


def _skip_ws_comments(text, i):
    n = len(text)
    while i < n:
        c = text[i]
        if c in " \t\r\n":
            i += 1
        elif c == "/" and i + 1 < n and text[i + 1] == "/":
            j = text.find("\n", i)
            i = n if j < 0 else j + 1
        elif c == "/" and i + 1 < n and text[i + 1] == "*":
            j = text.find("*/", i + 2)
            if j < 0:
                raise JsoncError("unterminated /* comment")
            i = j + 2
        else:
            break
    return i


def _scan_string(text, i):
    """text[i] is the opening quote; return the index past the closing one."""
    n = len(text)
    i += 1
    while i < n:
        c = text[i]
        if c == "\\":
            i += 2
            continue
        if c == '"':
            return i + 1
        i += 1
    raise JsoncError("unterminated string")


def _scan_value(text, i):
    """text[i] is the first char of a value; return the index past the value."""
    n = len(text)
    c = text[i]
    if c == '"':
        return _scan_string(text, i)
    if c in "[{":
        depth = 0
        while i < n:
            ch = text[i]
            if ch == '"':
                i = _scan_string(text, i)
                continue
            if ch == "/" and i + 1 < n and text[i + 1] in "/*":
                i = _skip_ws_comments(text, i)
                continue
            if ch in "[{":
                depth += 1
            elif ch in "]}":
                depth -= 1
                if depth == 0:
                    return i + 1
            i += 1
        raise JsoncError("unterminated array or object")
    # number, true, false, null
    j = i
    while j < n and text[j] not in ",}]/" and not text[j].isspace():
        j += 1
    if j == i:
        raise JsoncError(f"unexpected character {c!r} at offset {i}")
    return j


def iter_top_level(text):
    """Yield (name, key_start, value_start, value_end) for the root object."""
    i = _skip_ws_comments(text, 0)
    if i >= len(text) or text[i] != "{":
        raise JsoncError("the root of the file is not a JSON object")
    i += 1
    while True:
        i = _skip_ws_comments(text, i)
        if i >= len(text):
            raise JsoncError("unterminated root object")
        c = text[i]
        if c == "}":
            return
        if c == ",":
            i += 1
            continue
        if c != '"':
            raise JsoncError(f"expected a key at offset {i}, found {c!r}")
        k_start = i
        k_end = _scan_string(text, i)
        name = json.loads(text[k_start:k_end])
        i = _skip_ws_comments(text, k_end)
        if i >= len(text) or text[i] != ":":
            raise JsoncError(f"expected ':' after key {name!r}")
        i = _skip_ws_comments(text, i + 1)
        v_start = i
        v_end = _scan_value(text, i)
        yield name, k_start, v_start, v_end
        i = v_end


def find_top_level(text, key):
    for name, k_start, v_start, v_end in iter_top_level(text):
        if name == key:
            return k_start, v_start, v_end
    return None


def strip_jsonc(text):
    """Comments -> spaces (offsets kept), trailing commas dropped. For json.loads."""
    out = []
    i = 0
    n = len(text)
    while i < n:
        c = text[i]
        if c == '"':
            j = _scan_string(text, i)
            out.append(text[i:j])
            i = j
        elif c == "/" and i + 1 < n and text[i + 1] in "/*":
            j = _skip_ws_comments(text, i)
            # keep newlines so line numbers in errors still make sense
            out.append("".join(ch if ch == "\n" else " " for ch in text[i:j]))
            i = j
        else:
            out.append(c)
            i += 1
    return re.sub(r",(\s*[}\]])", r" \1", "".join(out))


def check_parses(text, what):
    try:
        json.loads(strip_jsonc(text))
    except (JsoncError, ValueError) as exc:
        sys.exit(f"error: {what} is not valid JSON/JSONC: {exc}")


def line_indent(text, pos):
    """The leading whitespace of the line `pos` sits on, if pos follows only it."""
    start = text.rfind("\n", 0, pos) + 1
    prefix = text[start:pos]
    return prefix if prefix.strip() == "" else ""


def reindent(block, old, new):
    if old == new:
        return block
    lines = block.split("\n")
    out = [lines[0]]
    for ln in lines[1:]:
        if old and ln.startswith(old):
            out.append(new + ln[len(old):])
        elif not ln.strip():
            out.append(ln)
        elif not old:
            out.append(new + ln)
        else:
            out.append(ln)
    return "\n".join(out)


def dominant_newline(text):
    return "\r\n" if text.count("\r\n") > text.count("\n") - text.count("\r\n") else "\n"


# --------------------------------------------------------------------------
# Finding the target file
# --------------------------------------------------------------------------

def _wsl_localappdata():
    """%LOCALAPPDATA% as a Linux path, or None if this is not WSL."""
    if not Path("/proc/version").exists():
        return None
    try:
        if "microsoft" not in Path("/proc/version").read_text().lower():
            return None
    except OSError:
        return None

    win_path = None
    try:
        # cwd on /mnt/c so cmd.exe does not complain about a UNC working dir
        res = subprocess.run(["cmd.exe", "/c", "echo %LOCALAPPDATA%"],
                             cwd="/mnt/c", capture_output=True, text=True, timeout=20)
        cand = res.stdout.strip()
        if res.returncode == 0 and cand and "%" not in cand:
            win_path = cand
    except (OSError, subprocess.SubprocessError):
        pass

    if win_path:
        try:
            res = subprocess.run(["wslpath", "-u", win_path],
                                 capture_output=True, text=True, timeout=20)
            if res.returncode == 0 and res.stdout.strip():
                return Path(res.stdout.strip())
        except (OSError, subprocess.SubprocessError):
            pass
        # wslpath missing: translate C:\Users\x\... by hand
        m = re.match(r"^([A-Za-z]):[\\/](.*)$", win_path)
        if m:
            return Path(f"/mnt/{m.group(1).lower()}") / m.group(2).replace("\\", "/")

    # last resort: the only user profile under /mnt/c/Users that has a WT config
    hits = []
    users = Path("/mnt/c/Users")
    if users.is_dir():
        for home in sorted(users.iterdir()):
            local = home / "AppData" / "Local"
            if any((local / rel).exists() for rel in TARGET_CANDIDATES):
                hits.append(local)
    if len(hits) == 1:
        return hits[0]
    return None


def localappdata():
    if os.name == "nt":
        env = os.environ.get("LOCALAPPDATA")
        return Path(env) if env else None
    return _wsl_localappdata()


def find_targets():
    base = localappdata()
    if base is None:
        return []
    return [base / rel for rel in TARGET_CANDIDATES if (base / rel).is_file()]


# --------------------------------------------------------------------------

def resolve_source(arg):
    p = Path(arg)
    if p.is_file():
        return p
    for cand in (SCRIPT_DIR / arg,
                 SCRIPT_DIR / f"{arg}.json",
                 SCRIPT_DIR / f"{arg}-win-terminal-settings.json"):
        if cand.is_file():
            return cand
    sys.exit(f"error: no such config file: {arg}\n"
             f"       (also looked for it in {SCRIPT_DIR})")


def list_sources():
    return sorted(p for p in SCRIPT_DIR.glob("*.json") if p.name != "settings.json")


def read_text(path):
    data = path.read_bytes()
    bom = data.startswith(b"\xef\xbb\xbf")
    return data.decode("utf-8-sig"), bom


def backup(target):
    stamp = datetime.date.today().isoformat()
    name = f"{target.stem}-{stamp}{target.suffix}"
    dest = target.with_name(name)
    n = 2
    while dest.exists():  # never overwrite an earlier backup from the same day
        dest = target.with_name(f"{target.stem}-{stamp}-{n}{target.suffix}")
        n += 1
    shutil.copyfile(target, dest)  # copy/copy2 fail: /mnt/c chmod/utime denied on some files (WSL 9p quirk)
    return dest


def main():
    ap = argparse.ArgumentParser(
        description=f'Replace the "{SECTION}" section of the Windows Terminal '
                    "settings.json with the one from a config file.")
    ap.add_argument("source", nargs="?",
                    help="config file to take the section from; a bare name like "
                         "'b45' is resolved against this script's folder")
    ap.add_argument("-t", "--target", help="settings.json to modify "
                                           "(default: the detected Windows Terminal one)")
    ap.add_argument("-n", "--dry-run", action="store_true",
                    help="show the diff, write nothing")
    ap.add_argument("-l", "--list", action="store_true",
                    help="list the available configs and the detected target, then exit")
    args = ap.parse_args()

    targets = find_targets()

    if args.list:
        print(f"configs in {SCRIPT_DIR}:")
        for p in list_sources():
            print(f"  {p.name}")
        print("\nwindows terminal settings found:")
        for p in targets:
            print(f"  {p}")
        if not targets:
            print("  (none)")
        return

    if not args.source:
        ap.error("a source config file is required (or use --list)")

    src_path = resolve_source(args.source)

    if args.target:
        tgt_path = Path(args.target)
        if not tgt_path.is_file():
            sys.exit(f"error: no such file: {tgt_path}")
    elif targets:
        tgt_path = targets[0]
        if len(targets) > 1:
            print(f"note: {len(targets)} installs found, using the first one; "
                  f"pass --target to pick another")
    else:
        sys.exit("error: could not find the Windows Terminal settings.json.\n"
                 "       Pass one explicitly with --target PATH.")

    if src_path.resolve() == tgt_path.resolve():
        sys.exit("error: source and target are the same file")

    src_text, _ = read_text(src_path)
    tgt_text, tgt_bom = read_text(tgt_path)
    check_parses(src_text, str(src_path))
    check_parses(tgt_text, str(tgt_path))

    src_span = find_top_level(src_text, SECTION)
    if src_span is None:
        sys.exit(f'error: {src_path} has no top-level "{SECTION}" section')
    s_key, s_val, s_end = src_span
    block = src_text[s_val:s_end]

    nl = dominant_newline(tgt_text)
    tgt_span = find_top_level(tgt_text, SECTION)

    if tgt_span is not None:
        t_key, t_val, t_end = tgt_span
        block = reindent(block, line_indent(src_text, s_key), line_indent(tgt_text, t_key))
        new_text = tgt_text[:t_val] + block + tgt_text[t_end:]
    else:
        # no such section yet: append it as the last key of the root object
        keys = list(iter_top_level(tgt_text))
        indent = line_indent(tgt_text, keys[0][1]) if keys else "    "
        block = reindent(block, line_indent(src_text, s_key), indent)
        root_end = _scan_value(tgt_text, _skip_ws_comments(tgt_text, 0))
        close = tgt_text.rindex("}", 0, root_end)
        head = tgt_text[:close].rstrip()
        sep = "," if keys else ""
        new_text = (head + sep + "\n" + indent + f'"{SECTION}": ' + block
                    + "\n" + line_indent(tgt_text, close) + tgt_text[close:])
        print(f'note: the target had no "{SECTION}" section; adding one')

    # the spliced block may carry the source's line endings; unify the file
    new_text = new_text.replace("\r\n", "\n")
    if nl != "\n":
        new_text = new_text.replace("\n", nl)

    check_parses(new_text, "the result")

    if new_text == tgt_text:
        print(f"{tgt_path}\nalready up to date, nothing to do")
        return

    diff = difflib.unified_diff(tgt_text.splitlines(), new_text.splitlines(),
                                fromfile=str(tgt_path), tofile=f"{tgt_path} (new)",
                                lineterm="", n=2)
    if args.dry_run:
        print("\n".join(diff))
        print(f"\ndry run: {tgt_path} not modified")
        return

    bak = backup(tgt_path)
    with open(tgt_path, "w", encoding="utf-8-sig" if tgt_bom else "utf-8",
              newline="") as fh:
        fh.write(new_text)

    added = sum(1 for ln in diff if ln.startswith("+") and not ln.startswith("+++"))
    print(f"backup:  {bak}")
    print(f"updated: {tgt_path}")
    print(f'"{SECTION}" taken from {src_path} ({added} lines written)')


if __name__ == "__main__":
    main()
