#!/usr/bin/env python3
"""Reset the "keybindings" section of the Windows Terminal settings.json to
the Windows Terminal default.

The default is the "keybindings" section of the installed defaults.json, plus
the entries a fresh settings.json adds on top (FRESH_INSTALL). defaults.json
ships inside the MSIX package, under a directory named after the package
version. C:\\Program Files\\WindowsApps cannot be listed without elevation,
but a file inside it can be read by its exact path, so the package name comes
from the registry.

Everything else is shared with apply-keybindings.py: target detection, the
text splice, validation, and the settings-YYYY-MM-DD.json backup.
"""

import argparse
import importlib.util
import os
import re
import subprocess
import sys
from pathlib import Path

REG_KEY = (r"HKCU\Software\Classes\Local Settings\Software\Microsoft\Windows"
           r"\CurrentVersion\AppModel\Repository\Packages")
PKG_RE = re.compile(r"Microsoft\.WindowsTerminal_([\d.]+)_x64__8wekyb3d8bbwe")

# A fresh settings.json binds these; defaults.json does not.
FRESH_INSTALL = """
        // from a fresh settings.json, not in defaults.json
        { "keys": "ctrl+c", "id": "Terminal.CopyToClipboard" },
        { "keys": "ctrl+v", "id": "Terminal.PasteFromClipboard" },
        { "keys": "alt+shift+d", "id": "Terminal.DuplicatePaneAuto" }
"""


def load_apply():
    # the file name has a hyphen, so a plain import cannot reach it
    path = Path(__file__).resolve().parent / "apply-keybindings.py"
    spec = importlib.util.spec_from_file_location("apply_keybindings", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


# Same lookup as ../winterm-cfgs-links/relink-wt-defaults.py. Copied, because
# this folder ships alone as a zip (dev-D10), without that one.
def find_defaults_json():
    # cwd=/mnt/c on WSL: cmd-family tools warn when the cwd is a UNC path
    cwd = "/mnt/c" if os.path.isdir("/mnt/c") else None
    try:
        out = subprocess.run(["reg.exe", "query", REG_KEY], cwd=cwd,
                             capture_output=True, text=True, timeout=20).stdout
    except (OSError, subprocess.SubprocessError):
        out = ""
    found = {m.group(1): m.group(0) for m in PKG_RE.finditer(out)}
    if not found:
        sys.exit("error: no Windows Terminal package found in the registry.\n"
                 "       Pass defaults.json explicitly with --defaults PATH.")
    newest = max(found, key=lambda v: [int(p) for p in v.split(".")])
    win_path = "C:\\Program Files\\WindowsApps\\" + found[newest] + "\\defaults.json"
    if os.name == "nt":
        return Path(win_path)
    drive, rest = win_path.split(":", 1)
    return Path("/mnt/" + drive.lower() + rest.replace("\\", "/"))


def default_section(apply, defaults_path):
    """A JSONC text whose only key is the default "keybindings" section."""
    text, _ = apply.read_text(defaults_path)
    apply.check_parses(text, str(defaults_path))
    span = apply.find_top_level(text, apply.SECTION)
    if span is None:
        sys.exit(f'error: {defaults_path} has no top-level "{apply.SECTION}" section')
    _, v_start, v_end = span
    block = text[v_start:v_end].replace("\r\n", "\n")
    head = block[:-1].rstrip()  # everything before the closing ]
    if not head.endswith(("[", ",")):
        head += ","
    return ('{\n    "' + apply.SECTION + '": ' + head + "\n"
            + FRESH_INSTALL + "    ]\n}\n")


def main():
    ap = argparse.ArgumentParser(
        description='Reset the "keybindings" section of the Windows Terminal '
                    "settings.json to the Windows Terminal default.")
    ap.add_argument("-t", "--target", help="settings.json to modify "
                                           "(default: the detected Windows Terminal one)")
    ap.add_argument("-d", "--defaults", help="Windows Terminal's defaults.json "
                                             "(default: found through the registry)")
    ap.add_argument("-n", "--dry-run", action="store_true",
                    help="show the diff, write nothing")
    args = ap.parse_args()

    apply = load_apply()
    tgt_path = apply.pick_target(args.target, apply.find_targets())
    defaults_path = Path(args.defaults) if args.defaults else find_defaults_json()
    if not defaults_path.is_file():
        sys.exit(f"error: not readable: {defaults_path}")

    src_text = default_section(apply, defaults_path)
    apply.apply_section(src_text, f"{defaults_path} + fresh-install entries",
                        tgt_path, args.dry_run)


if __name__ == "__main__":
    main()
