#!/bin/sh
# Remove what a wxl binary install put down -- local or system-wide.
#
# Shipped in every build/<app>.tar.gz as uninstall.sh and copied by install.sh
# next to the manifest it reads: ~/.local/share/wxl/ for a local install,
# <prefix>/share/wxl/ (normally /usr/local/share/wxl/) for a system-wide one.
# So it works after the release folder is gone:
#
#     sh ~/.local/share/wxl/uninstall.sh [APP...]
#     sudo sh /usr/local/share/wxl/uninstall.sh [APP...]
#
# It removes only files the manifest lists, and only while they are unchanged
# since the install: a uv shim that a source install has since written over a
# binary is left alone. Settings and state (~/.config/<app>) are never
# touched. POSIX sh plus coreutils and awk, like install.sh.
set -eu

here="$(cd -- "$(dirname -- "$0")" && pwd)"
manifest="$here/manifest"

case "${1:-}" in
    -h|--help)
        echo "usage: sh $0 [APP...]   (default: every app installed here)" >&2
        exit 0 ;;
esac

if [ ! -f "$manifest" ]; then
    echo "uninstall.sh: nothing is installed from $here"
    exit 0
fi
if [ ! -w "$manifest" ]; then
    echo "uninstall.sh: cannot write $here -- a system-wide install is removed" \
         "with: sudo sh $0" >&2
    exit 1
fi

# Which tier this is: the user's own share dir is the local one, anything
# else was a system-wide install. wxlrc.sh reads $WXL_SYSTEM_DIR to find the
# matching dev-wxl.sh.
user_share="${XDG_DATA_HOME:-$HOME/.local/share}/wxl"
if [ -d "$user_share" ] && [ "$here" = "$(cd -- "$user_share" && pwd)" ]; then
    unset WXL_SYSTEM_DIR
    system=no
else
    WXL_SYSTEM_DIR="$here"
    export WXL_SYSTEM_DIR
    system=yes
fi
WXL_MANIFEST="$manifest"
export WXL_MANIFEST
. "$here/wxlrc.sh"

if [ $# -gt 0 ]; then
    apps="$*"
else
    apps="$(awk '$1 == "f" { print $2 }' "$manifest" | sort -u)"
fi

bindirs=""
for app in $apps; do
    if ! awk -v a="$app" '$1 == "f" && $2 == a { found = 1 } END { exit !found }' \
            "$manifest"; then
        echo "$app: not installed from $here"
        continue
    fi
    echo "== $app =="
    ccx_rc=""
    while read -r kind a crc size path; do
        [ "$kind" = f ] && [ "$a" = "$app" ] || continue
        case "$path" in
            */"$app") bindirs="$bindirs
$(dirname "$path")" ;;
            */ccx-rc.sh) ccx_rc="$path" ;;
        esac
        if [ ! -e "$path" ]; then
            continue
        fi
        if [ "$(cksum <"$path")" = "$crc $size" ]; then
            rm -f "$path"
            echo "removed $path"
            case "$path" in
                */"$app") ;;
                # Empty folders the install made go too -- only the app's
                # own and its words/, never a parent like ~/.config.
                *) d="$(dirname "$path")"
                   while case "$(basename "$d")" in "$app"|words) true ;;
                                                    *) false ;; esac &&
                         rmdir "$d" 2>/dev/null; do
                       d="$(dirname "$d")"
                   done ;;
            esac
        else
            echo "left alone, changed since the install (another install" \
                 "owns it now): $path"
        fi
    done <"$manifest"

    # The ccx block is this tier's only while it points at this tier's rc
    # file; a source install's block points at the checkout instead.
    if [ -n "$ccx_rc" ] && wxl_only "$(wxl_file)" ccx | grep -qF "$ccx_rc"; then
        wxl_unblock ccx
    fi
    wxl_manifest_forget "$app"
done

# Anything left? Then the shared wiring stays for the remaining apps.
if awk '$1 == "f" { found = 1 } END { exit !found }' "$manifest"; then
    exit 0
fi

if [ "$system" = yes ]; then
    awk '$1 == "r" { print $5 }' "$manifest" | while read -r rc; do
        wxl_rc_unblock "$rc" wxl
    done
    rm -f "$(wxl_file)"
else
    # The PATH guard is shared with the source install's uv shims, which
    # live in the same directory; it goes only when none of those is left.
    keep=no
    for d in $(printf '%s\n' "$bindirs" | sort -u); do
        if grep -ls 'install.py -- do not edit' "$d"/* >/dev/null 2>&1; then
            keep=yes
        fi
    done
    [ "$keep" = yes ] || wxl_unblock path
    echo ""
    echo "$(wxl_file) was kept for any other wiring in it. If it has no"
    echo "blocks left, you may delete it and the line in ~/.bashrc that"
    echo "sources it."
fi

rm -f "$manifest" "$here/wxlrc.sh" "$here/uninstall.sh"
rmdir "$here" 2>/dev/null || true
echo "settings and state (~/.config/<app>) were left in place."
