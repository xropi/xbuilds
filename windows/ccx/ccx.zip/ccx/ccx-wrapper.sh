# ccx shell integration. Source it from your shell rc; install.py writes the
# line into ~/.local/share/dev-wxl.sh (dev-D11) for you. Four separate jobs,
# and only the first one runs in your own shells — the other three are guarded
# on $CCX, which only the ccx that hosts the shell exports:
#
#   1. the `ccx` command as a shell *function*, so cd-on-exit can change the
#      cwd of the shell you are typing in (D16) — a program never can;
#   2. the invisible prompt/command marks bash prints around every command
#      (OSC 133, D9/D33). ccx reads them to know where the command line
#      starts and when a command has finished — which is what lets it hand
#      the whole terminal to a command and take it back afterwards (D56);
#   3. the silent directory change (D71): ccx asks the shell to `cd` where
#      the panel went, without typing anything on your command line;
#   4. the shell reporting its own directory back (OSC 7), so a panel can
#      follow a `cd` you typed yourself (D86);
#   5. the history list (D137): ccx asks the shell for its history and puts
#      the entry you picked on the command line, again without typing;
#   6. the command names for ccx's Tab list (D176): aliases, functions,
#      builtins and PATH, written to a file before every prompt.
#
# Works in bash (BASH_SOURCE) and zsh ($0 is the sourced file there); jobs 2-6
# are bash-only.
#
# Only job 1 needs your rc to source this file. Jobs 2-6 reach the hosted
# shell either way: ccx spawns bash with a generated `--rcfile` that sources
# your ~/.bashrc and then this file (D126), guarded on the .ready marker
# below so a shell whose rc already ran it does not run it twice.

_ccx_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]:-$0}")" && pwd)"

ccx() {
    # $XDG_RUNTIME_DIR is set but missing wherever there is no login
    # session -- a container that forwards the variable without the mount,
    # `sudo -u`, ssh without a session -- and uid-owned /run/user/<uid>
    # cannot be created from here, so use it only where it can be written
    # to and fall back to the plain temp dir otherwise (B27).
    local ccx_run="${XDG_RUNTIME_DIR:-}" rc
    [ -n "$ccx_run" ] && [ -d "$ccx_run" ] && [ -w "$ccx_run" ] || ccx_run="${TMPDIR:-/tmp}"
    local ccx_cwd="$ccx_run/ccx-cwd.$$" ccx_arg
    # git bash (D199): the ccx started here is a Windows program, so it is
    # handed the file as `C:\...`. What it writes back is `D:\...`, which
    # git bash's `cd` below takes as it is.
    ccx_arg="$ccx_cwd"
    [ -n "${MSYSTEM:-}" ] && ccx_arg="$(cygpath -w "$ccx_cwd")"
    # $CCX_BIN is the frozen-binary install (pylib-D1): ccx-install-hook.sh
    # writes a small rc file that sets it and sources this same wrapper, so
    # cd-on-exit exists in one place for both install kinds rather than
    # being copied into a generated binary-only wrapper. The path is
    # absolute, so this function cannot recurse into itself. Unset on a
    # source install, where the two branches below are all there ever was.
    #
    # Source install: launch through ccx.py's own uv shebang, so the `ccx`
    # command and `./ccx.py` resolve dependencies the same way (the PEP 723
    # block + editable ../pylib).
    #
    # There is no python3 fallback any more (pylib-D3): nothing installs
    # ccx's dependencies into site-packages, so that branch could only start
    # an interpreter that dies on `import wcwidth`. Saying why, once, beats a
    # traceback -- and unlike the frozen binary, a source install genuinely
    # cannot run without uv.
    if [ -x "${CCX_BIN:-}" ]; then
        "$CCX_BIN" --cwd-file "$ccx_arg" "$@"
    elif [ -n "${MSYSTEM:-}" ] && command -v uv >/dev/null 2>&1; then
        # git bash: start the script's environment the way ccx.cmd does,
        # not through the uv shebang -- uv.exe exits on Ctrl+Break while
        # ccx still restores the console (pylib-D32).
        local ccx_script ccx_py
        ccx_script="$(cygpath -w "$_ccx_dir/ccx.py")"
        uv sync --quiet --managed-python --script "$ccx_script" || return 1
        ccx_py="$(uv python find --managed-python --script "$ccx_script")" \
            || return 1
        "$ccx_py" "$ccx_script" --cwd-file "$ccx_arg" "$@"
    elif command -v uv >/dev/null 2>&1; then
        "$_ccx_dir/ccx.py" --cwd-file "$ccx_cwd" "$@"
    else
        echo "ccx: uv is not installed or not on PATH -- run install.py" >&2
        return 127
    fi
    rc=$?
    if [ -r "$ccx_cwd" ]; then
        cd -- "$(cat "$ccx_cwd")"
        rm -f "$ccx_cwd"
    fi
    return $rc
}

# OSC 133 semantic-prompt marks inside ccx's own console (design D9/D33). Only
# when $CCX is set (exported by the hosting ccx, so this never touches your
# normal shells) and only under bash: the shell emits FinalTerm/OSC 133 marks
# around the prompt and command, which ccx reads to recover the command line
# you typed — so Shift+Enter in the console runs *that* command full-screen
# (handoff) instead of in the embedded shell. The marks are appended to your
# existing PS1/PS0/PROMPT_COMMAND, so your own prompt is preserved; the B mark
# is wrapped in \[ \] so readline still counts it as zero-width. Idempotent:
# the guards below skip re-adding on a second source.
if [ -n "$CCX" ] && [ -n "$BASH_VERSION" ]; then
    # The cwd report (OSC 7). git bash's $PWD is `/c/dev`, which
    # Windows-side ccx cannot use, so there it is `pwd -W`'s `C:/dev`
    # (B43). Elsewhere plain $PWD: no subshell on every prompt.
    if [ -n "${MSYSTEM:-}" ]; then
        __ccx_osc7() {
            printf '\033]7;file://%s/%s\a' "${HOSTNAME:-}" "$(pwd -W)"
        }
    else
        __ccx_osc7() {
            printf '\033]7;file://%s%s\a' "${HOSTNAME:-}" "$PWD"
        }
    fi
    # done + prompt-start, then where the shell now is (OSC 7). The cwd
    # report belongs on *every* prompt, not only after the D71 widget's cd
    # (B19): ccx prefers the last OSC 7 it saw over reading /proc, so a
    # report emitted from one path only is worse than none — it pins ccx's
    # idea of the shell to wherever that path last left it, and every cd
    # typed by hand afterwards goes unseen.
    # Every mark carries `;ccx=<pid of the hosting ccx>` (D129): a shell
    # nested inside a command — a ccx run from ccx's console — emits the
    # same marks, and without the tag its first D ended the outer ccx's
    # wait for its *own* command (B28). Terminals ignore the parameter.
    __ccx_osc133_precmd() {
        printf '\033]133;D;ccx=%s\a\033]133;A;ccx=%s\a' "$CCX" "$CCX"
        __ccx_osc7
    }
    case ";${PROMPT_COMMAND};" in
        *__ccx_osc133_precmd*) ;;
        *) PROMPT_COMMAND="__ccx_osc133_precmd${PROMPT_COMMAND:+;$PROMPT_COMMAND}" ;;
    esac
    case "$PS1" in
        *']133;B'*) ;;                              # prompt-end -> command text starts
        *) PS1="${PS1}\[\e]133;B;ccx=${CCX}\a\]" ;;
    esac
    case "$PS0" in
        *']133;C'*) ;;                              # command accepted, output starting
        *) PS0="${PS0}\e]133;C;ccx=${CCX}\a" ;;
    esac
fi

# Silent panel-cd channel (design D71). Same $CCX guard as the OSC 133 block
# above — this only ever exists inside a shell ccx hosts. ccx writes the
# target path to $CCX_CD_FILE and sends the key sequence bound below;
# readline runs __ccx_cd in *this* shell, which is what makes the cd stick.
#
# The point is that it is a readline widget rather than a command: a widget
# is not accept-line, so nothing is echoed, no row is left in the console's
# scrollback, nothing enters .bash_history or Up-recall, and the line the
# user was half-way through typing stays on the prompt. Typing `cd <path>`
# — what ccx falls back to without this — does all four.
#
# The .ready marker is the handshake: ccx sends the sequence only once it
# exists, since an unbound sequence would be inserted into the line as text.
if [ -n "$CCX" ] && [ -n "$BASH_VERSION" ] && [ -n "${CCX_CD_FILE:-}" ]; then
    case $- in
        *i*)
            __ccx_cd() {
                local dir mode rows
                { IFS= read -r dir; IFS= read -r mode; IFS= read -r rows; } \
                    < "$CCX_CD_FILE" 2>/dev/null
                # ccx writes a second line, `refresh`, when it is going to
                # follow this widget with the empty accept-line described
                # below. The flag must not outlive that one prompt cycle:
                # set from every cd, it survived until whatever the user
                # ran next, and ate a line of *that* command's output.
                # A third line is the prompt's height as ccx saw it drawn,
                # from the A mark to the B mark (B47); the hook below
                # trusts it over its own count.
                if [ "$mode" = refresh ]; then
                    case $rows in
                        ''|*[!0-9]*) __ccx_cd_moved=count ;;
                        *) __ccx_cd_moved=$rows ;;
                    esac
                fi
                [ -n "$dir" ] || return 0
                builtin cd -- "$dir" 2>/dev/null || return 0
                # PROMPT_COMMAND does not run after a widget, so report the
                # new cwd here — otherwise ccx's OSC 7 view of the shell
                # would silently drift from where the shell actually is.
                __ccx_osc7
            }
            # A prompt showing \w is stale after the widget: bash expands
            # PS1 once per readline call, and the widget runs *inside* one,
            # so the prompt on screen still names the old directory until
            # something ends that call. ccx therefore follows the widget
            # with an empty accept-line, which costs no history entry and
            # runs no command but does start a fresh prompt — and this hook
            # then erases the prompt the newline left behind, so the new one
            # is drawn over it and the console gains no rows at all. Up by
            # the height of the old prompt block (its own newline count,
            # PS1 being the same string), then clear to the end of the
            # screen: a two-line prompt must not leave half of itself.
            # The count is read from the raw PS1 — `\n`, `\012` and real
            # newlines — never from `${PS1@P}`: expanding runs the prompt's
            # commands, and git bash's `__git_ps1` forks git, ~90 ms each,
            # on top of the real prompt's own call (B45). A command in PS1
            # that prints a newline itself is not counted.
            # The count from PS1 is only the fallback for a ccx that sent
            # no height: a newline in the source need not print one. A
            # dev-container PS1 continues lines with backslash-newline
            # inside a `...` command — five source lines, one row — and
            # the erase then ate four rows of output per panel cd (B47).
            __ccx_cd_precmd() {
                [ -n "$__ccx_cd_moved" ] || return 0
                local moved=$__ccx_cd_moved
                __ccx_cd_moved=
                if [ "$moved" != count ]; then
                    printf '\033[%dA\r\033[J' "$moved"
                    return 0
                fi
                [ -n "$PS1" ] || return 0
                # The backslash through a variable: quoted backslashes in
                # a pattern are not literal (bash 5.2 matches '\\' against
                # one backslash); "${bs}n" is. Every `\n`
                # counts, `\\n` too — bash's own prompt turns it into a
                # newline as well.
                local bs='\' lines=1 rest=$PS1
                rest=${rest//"${bs}n"/$'\n'}
                rest=${rest//"${bs}012"/$'\n'}
                while [ "${rest#*$'\n'}" != "$rest" ]; do
                    rest=${rest#*$'\n'}
                    lines=$((lines + 1))
                done
                printf '\033[%dA\r\033[J' "$lines"
            }
            case ";${PROMPT_COMMAND};" in
                *__ccx_cd_precmd*) ;;
                *) PROMPT_COMMAND="__ccx_cd_precmd${PROMPT_COMMAND:+;$PROMPT_COMMAND}" ;;
            esac
            # Bound in both keymaps by name rather than in whichever one
            # happens to be current: `set -o vi` further down the rc file
            # would otherwise leave the binding in emacs-standard only,
            # and the sequence would arrive as text on the prompt.
            # The history list (D137). Up at ccx's console sends \e[98~:
            # dump the shell's own, in-memory history — this session's
            # commands included, which ~/.bash_history does not have yet —
            # then, after a mark, the whole history file, which holds more
            # than the HISTSIZE entries the shell loaded and the commands
            # other shells have saved since (ccx merges the two). End the
            # file with a mark, so ccx never reads half of it.
            # A widget for the D71 reasons: no echo, no scrollback row, no
            # history entry. Picking an entry is ccx's alone: the command
            # line is ccx's own buffer (D162), so nothing is sent here.
            # Keep command substitutions out of every widget: in bash 5.2
            # one inside a `bind -x` breaks the parse of the next line
            # (B38).
            __ccx_hist() {
                { HISTTIMEFORMAT= builtin history
                  printf '%s\n' __ccx_hist_file__
                  [ -r "${HISTFILE:-}" ] && cat -- "$HISTFILE"
                  printf '\n%s\n' __ccx_hist_end__; } \
                    > "$CCX_CD_FILE.hist" 2>/dev/null
            }
            # Command names for ccx's Tab list (D176): before every
            # prompt, the aliases, functions, builtins and keywords this
            # shell knows, and its PATH (ccx reads the directories
            # itself). Before every prompt, because an alias or function
            # defined at the prompt counts from the next one. All
            # builtins, so it forks nothing; the end mark tells ccx the
            # file is whole. Keeps $? for the user's own PROMPT_COMMAND.
            __ccx_cmds_precmd() {
                local rc=$?
                { printf '%s\n' @alias; compgen -a
                  printf '%s\n' @function; compgen -A function
                  printf '%s\n' @builtin; compgen -b; compgen -k
                  printf '@path\n%s\n@end\n' "$PATH"; } \
                    > "$CCX_CD_FILE.cmds" 2>/dev/null
                return $rc
            }
            case ";${PROMPT_COMMAND};" in
                *__ccx_cmds_precmd*) ;;
                *) PROMPT_COMMAND="__ccx_cmds_precmd${PROMPT_COMMAND:+;$PROMPT_COMMAND}" ;;
            esac
            if bind -m emacs-standard -x '"\e[98~": __ccx_hist' 2>/dev/null; then
                bind -m vi-insert -x '"\e[98~": __ccx_hist' 2>/dev/null
                : > "$CCX_CD_FILE.hist-ready"
            fi
            if bind -m emacs-standard -x '"\e[99~": __ccx_cd' 2>/dev/null; then
                bind -m vi-insert -x '"\e[99~": __ccx_cd' 2>/dev/null
                : > "$CCX_CD_FILE.ready"
            fi
            ;;
    esac
fi

# Optional auto-spawn (design D31/D47), opt-in: both installers append
#
#   # ccx_autospawn  # ccx auto-spawn (D31) -- uncomment to opt in
#
# to ~/.bashrc, after the line sourcing this file and as the *last* ccx line
# in the file (D47) — enable it by uncommenting it there. It must stay after
# the source line so `ccx` resolves to the wrapper function and cd-on-exit
# keeps working, and last in the file because everything below an enabled
# auto-spawn line only runs once you quit ccx — i.e. the rest of your rc
# never reaches the shell ccx is hosting.
#
# The guard chain lives here, in the one file both install kinds share, so
# that neither installer carries a copy of it: ccx/install.py writes the call
# and ccx-install-hook.sh writes the same call on a binary install (D47). A
# guard added here therefore reaches both, and install.py's refresh migrates
# an older line that still spelled the chain out inline.
ccx_autospawn() {
    [ -n "${CCX:-}" ] && return 0                    # already inside ccx
    [ -n "${MC_SID:-}" ] && return 0                 # mc's hidden subshell
    case $- in *i*) ;; *) return 0 ;; esac           # interactive only
    [ -t 0 ] || return 0                             # with a real tty
    # --autospawn is how ccx tells a shell-started run from a typed one:
    # an "auto" start directory (the shipped default, D131) then opens the
    # panels where the last session left them instead of in the fresh
    # terminal's home. A flag rather than a variable, so the console shell
    # inside ccx does not inherit it.
    ccx --autospawn
}

# The guards, in order: $CCX is exported by ccx into everything it spawns, so
# the console shell inside ccx never starts another one (recursion breaker);
# $MC_SID is exported by mc into the hidden subshell it runs its command line
# in — that subshell is spawned as `bash -rcfile ~/.bashrc` (mc's fallback
# when no ~/.config/mc/bashrc exists) and is interactive with a tty, so
# without this guard a full ccx starts inside it and mc hangs ~10s waiting
# for a prompt that never comes (B6); $- must contain "i" (interactive —
# Debian sources .bashrc even for ssh command execution, where a TUI would
# break scp/rsync/git-over-ssh); stdin must be a tty (an interactive-flagged
# shell can still have redirected streams). The interactive test is the POSIX
# `case $- in *i*)` rather than bash's `[[ $- == *i* ]]` — the function body
# stays shell-portable even though this file as a whole is bash/zsh (the
# ${BASH_SOURCE[0]} at the top is), so pasting the chain into a .profile that
# dash may read needs no rewrite.
#
# The first two guards are the same idea applied to two hosts: "an
# interactive shell with a tty" is not the same as "the shell the user is
# looking at". Any other program that runs an interactive shell in a pty of
# its own needs its own marker added here.
